# MediRoster-Frontend
Medi Roster is a mobile optimized Constraint Based Roster Scheduler for hospitals. This is the Frontend
