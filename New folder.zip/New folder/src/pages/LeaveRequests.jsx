import React from 'react'

const LeaveRequests = () => {
  return (
    <div>
      
    </div>
  )
}

export default LeaveRequests
