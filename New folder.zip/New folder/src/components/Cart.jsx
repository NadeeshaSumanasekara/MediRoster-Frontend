import React from 'react'

function Cart() {
  return (
    <div>This is the Cart</div>
  )
}

export default Cart